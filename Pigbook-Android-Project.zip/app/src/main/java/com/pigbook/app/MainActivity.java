package com.pigbook.app;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.graphics.Color;
public class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> pending;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  getWindow().setStatusBarColor(Color.rgb(250,225,235));
  getWindow().setNavigationBarColor(Color.rgb(250,225,235));
  web = new WebView(this); setContentView(web);
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true);
  web.setWebViewClient(new WebViewClient(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
    Uri u=r.getUrl(); if(!"https".equals(u.getScheme()) || !"pigbook.local".equals(u.getHost())) return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));
    String p=u.getPath(); if(p==null || p.equals("/")) p="/index.html";
    try { String mime=p.endsWith(".html")?"text/html":p.endsWith(".js")?"application/javascript":p.endsWith(".png")?"image/png":p.endsWith(".svg")?"image/svg+xml":"application/manifest+json"; return new WebResourceResponse(mime,"UTF-8",getAssets().open(p.substring(1))); } catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));}
   }
   @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){return !"pigbook.local".equals(r.getUrl().getHost());}
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
    if(pending!=null) pending.onReceiveValue(null); pending=cb;
    try {startActivityForResult(params.createIntent(),42);} catch(Exception e){pending.onReceiveValue(null);pending=null;} return true;
   }
  });
  web.loadUrl("https://pigbook.local/index.html");
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==42 && pending!=null){pending.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));pending=null;}}
}
