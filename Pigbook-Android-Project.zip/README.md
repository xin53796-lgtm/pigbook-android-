# 猪猪本 Android 工程
将本目录全部文件（包括隐藏的 .github 文件夹）上传到 GitHub 仓库根目录。进入 Actions → Build Pigbook APK → Run workflow。成功后在运行详情 Artifacts 下载 Pigbook-APK，解压获得 app-debug.apk。也可用 Android Studio 打开本目录，使用 Gradle 8.9、JDK 17、Android SDK 35 构建。当前工程尚未编译验证。调试签名仅供个人测试，正式发布需固定签名。原浏览器账本需先导出备份，再在 App 中恢复；卸载会清除本地数据。
